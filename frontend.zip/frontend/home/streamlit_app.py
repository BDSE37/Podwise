"""Podri TTS 前端 (Streamlit)
* 選擇 SoVITS 模型朗讀
* 支援下載 wav
"""
import streamlit as st
import base64
from providers.tts_manager import TTSManager
st.set_page_config(page_title="Podri GPT‑SoVITS", page_icon="🎤", layout="centered")

st.title("🎙 Podri GPT‑SoVITS 離線朗讀 DEMO")

text = st.text_area("輸入文字：", "哈囉，我是離線 Podri！")

tts = TTSManager()
models = list(tts.providers.keys())
model_choice = st.selectbox("選擇 TTS 模型：", models)
voices = tts.get_available_voices()
voice_choice = st.selectbox("選擇語音：", voices)

if st.button("🔊 朗讀"):
    with st.spinner("生成語音中…"):
        wav_bytes = tts.synthesize(text, model_choice, voice_choice)
    st.audio(wav_bytes, format="audio/wav")

    # 下載連結
    b64 = base64.b64encode(wav_bytes).decode()
    href = f'<a href="data:audio/wav;base64,{b64}" download="podri.wav">📥 下載語音</a>'
    st.markdown(href, unsafe_allow_html=True)